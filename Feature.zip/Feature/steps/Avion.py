class Avion(object):
    def __init__(self, reservoir=0.0, nb_passenger=0.0, poids=0.0):
        self.reservoir = float(reservoir)
        self.nbPassenger = float(nb_passenger)
        self.poids = float(poids)
        self.vol = []

    def set_Passenger(self, nb):
        self.nbPassenger = float(nb)

    def set_Reservoir(self, reservoir):
        self.reservoir = float(reservoir)

    def set_Poids(self, poids):
        self.poids = float(poids)

    def add_Vol(self, v):
        self.vol.append(v)

    def get_Passenger(self):
        return self.nbPassenger

    def get_Reservoir(self):
        return self.reservoir

    def get_Poids(self):
        return self.poids

    def add_Passenger(self, nb):
        self.nbPassenger += nb

    def calcul_Consommation(self):
        return (self.nbPassenger * 0.1 + self.poids) * 10

    def calcul_Distance(self):
        dist = (float(self.reservoir) / float(self.calcul_Consommation())) * 100
        for v in self.vol:
            if (v.crash(dist)):
                return 0
        return dist


