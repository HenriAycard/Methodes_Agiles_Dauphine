class Vol(object):
    def __init__(self, Ville_Depart, Ville_Arrivee, distance, nb_max_passenger):
        self.Ville_Depart = Ville_Depart
        self.Ville_Arrivee = Ville_Arrivee
        self.distance = float(distance)
        self.nb_max_passenger = float(nb_max_passenger)
        self.lst_avion = []

    def crash(self, dist):
        if self.distance > dist:
            return True
        return False

    def set_avion(self, a):
        self.lst_avion = a

    def add_avion(self, a):
        self.lst_avion.append(a)

    def calcul_nb_passenger_atc(self):
        resultat = 0.0
        for a in self.lst_avion:
            resultat += a.get_Passenger();
        return float(resultat)

    def is_max_passager(self):
        if self.nb_max_passenger > self.calcul_nb_passenger_atc():
            return True
        return False
